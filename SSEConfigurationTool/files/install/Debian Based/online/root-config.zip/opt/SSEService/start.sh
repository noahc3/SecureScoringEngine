/opt/SSEService/SSEService
